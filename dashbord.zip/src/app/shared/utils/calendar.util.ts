/**
 * Jalali (Persian) <-> Gregorian conversion using the standard jalaali
 * arithmetic algorithm (public domain, same math as jalaali-js) — embedded
 * here so the project has zero extra dependencies.
 */

export type CalSystem = 'jalali' | 'gregorian';

export interface CalDate {
  y: number;
  m: number; // 1-based
  d: number;
}

/* ---------------- core jalaali arithmetic ---------------- */

function div(a: number, b: number): number {
  return ~~(a / b);
}

function mod(a: number, b: number): number {
  return a - ~~(a / b) * b;
}

function g2d(gy: number, gm: number, gd: number): number {
  let d =
    div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
    div(153 * mod(gm + 9, 12) + 2, 5) +
    gd -
    34840408;
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

function d2g(jdn: number): { gy: number; gm: number; gd: number } {
  let j = 4 * jdn + 139361631;
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return { gy, gm, gd };
}

function jalCal(jy: number): { leap: number; gy: number; march: number } {
  const breaks = [
    -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097,
    2192, 2262, 2324, 2394, 2456, 3178,
  ];
  const bl = breaks.length;
  const gy = jy + 621;
  let leapJ = -14;
  let jp = breaks[0];

  let jump = 0;
  for (let i = 1; i < bl; i += 1) {
    const jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  let n = jy - jp;

  leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;

  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;

  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;

  return { leap, gy, march };
}

function j2d(jy: number, jm: number, jd: number): number {
  const r = jalCal(jy);
  return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
}

function d2j(jdn: number): CalDate {
  const gy = d2g(jdn).gy;
  let jy = gy - 621;
  const r = jalCal(jy);
  const jdn1f = g2d(gy, 3, r.march);
  let jd: number;
  let jm: number;
  let k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) {
      jm = 1 + div(k, 31);
      jd = mod(k, 31) + 1;
      return { y: jy, m: jm, d: jd };
    }
    k -= 186;
  } else {
    jy -= 1;
    k += 179;
    if (r.leap === 1) k += 1;
  }
  jm = 7 + div(k, 30);
  jd = mod(k, 30) + 1;
  return { y: jy, m: jm, d: jd };
}

export function isLeapJalali(jy: number): boolean {
  return jalCal(jy).leap === 0;
}

/* ---------------- public, calendar-agnostic API ---------------- */

export function dateToCal(date: Date, sys: CalSystem): CalDate {
  if (sys === 'gregorian') {
    return { y: date.getFullYear(), m: date.getMonth() + 1, d: date.getDate() };
  }
  return d2j(g2d(date.getFullYear(), date.getMonth() + 1, date.getDate()));
}

export function calToDate(c: CalDate, sys: CalSystem): Date {
  if (sys === 'gregorian') return new Date(c.y, c.m - 1, c.d);
  const { gy, gm, gd } = d2g(j2d(c.y, c.m, c.d));
  return new Date(gy, gm - 1, gd);
}

export function monthLength(y: number, m: number, sys: CalSystem): number {
  if (sys === 'gregorian') return new Date(y, m, 0).getDate();
  if (m <= 6) return 31;
  if (m <= 11) return 30;
  return isLeapJalali(y) ? 30 : 29;
}

export const JALALI_MONTHS = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];
export const GREGORIAN_MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

/** Week starts Saturday for Jalali, Sunday for Gregorian. */
export const JALALI_WEEKDAYS = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
export const GREGORIAN_WEEKDAYS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

export function monthNames(sys: CalSystem): string[] {
  return sys === 'jalali' ? JALALI_MONTHS : GREGORIAN_MONTHS;
}

export function weekdayNames(sys: CalSystem): string[] {
  return sys === 'jalali' ? JALALI_WEEKDAYS : GREGORIAN_WEEKDAYS;
}

/** Column index (0-6) of the 1st of the month in the grid of `sys`. */
export function firstDayOffset(y: number, m: number, sys: CalSystem): number {
  const first = calToDate({ y, m, d: 1 }, sys);
  const dow = first.getDay(); // 0=Sun .. 6=Sat
  return sys === 'jalali' ? (dow + 1) % 7 : dow;
}

const FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export function toPersianDigits(input: string | number): string {
  return String(input).replace(/\d/g, (d) => FA_DIGITS[Number(d)]);
}

export function pad2(n: number): string {
  return n < 10 ? `0${n}` : String(n);
}

export function formatCalDate(date: Date, sys: CalSystem, faDigits: boolean): string {
  const c = dateToCal(date, sys);
  const s = `${c.y}/${pad2(c.m)}/${pad2(c.d)}`;
  return faDigits ? toPersianDigits(s) : s;
}

export function formatTime(date: Date, faDigits: boolean): string {
  const s = `${pad2(date.getHours())}:${pad2(date.getMinutes())}`;
  return faDigits ? toPersianDigits(s) : s;
}

export function sameDay(a: Date | null, b: Date | null): boolean {
  return (
    !!a && !!b &&
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}
